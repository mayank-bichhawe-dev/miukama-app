const loginAuthProvider = {
  local: 'local',
  google: 'google',
  facebook: 'facebook',
  twitter: 'twitter',
  apple: 'apple',
};

module.exports = loginAuthProvider;

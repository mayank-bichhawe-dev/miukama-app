exports.s3ImageFolderName = {
  profile: 'profile',
  gallery: 'gallery',
  product: 'product',
  dashboardPost: 'dashboard-post',
};

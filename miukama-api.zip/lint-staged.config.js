module.exports = {
  '*.{js,ts,tsx}': ['eslint --fix', 'prettier --config ./.prettierrc -w ./'],
};

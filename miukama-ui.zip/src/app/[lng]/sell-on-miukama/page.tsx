'use client';

import CommingSoon from '@/components/commingSoon';

const Galleries = () => {
  return <CommingSoon title="Sell on Miukama" withBanner={true}></CommingSoon>;
};

export default Galleries;

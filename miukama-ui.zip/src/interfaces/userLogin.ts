export interface UserLogin {
  email: string;
  password: string;
}

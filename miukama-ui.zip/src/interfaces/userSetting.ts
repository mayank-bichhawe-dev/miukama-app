export interface notificationItemProps {
  id: number;
  heading: string;
  detail: string;
  checked: boolean;
}

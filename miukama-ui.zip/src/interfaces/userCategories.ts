export interface categoryFormData {
  id: number;
  categoryName: string;
}

export interface MenuList {
  id: number;
  currencyName?: string;
  LangaueName?: string;
  imageUrl?: string;
  languageImgUrl?: string;
  code?: string;
}

export interface Category {
  open: boolean;
  onClose: () => void;
  onSubmit: () => void;
}

'use client';

export interface UpdatePasswordInterface {
  oldPassword: string;
  password: string;
  confirmPassword: string;
}

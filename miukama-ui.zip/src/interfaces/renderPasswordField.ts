import { TextFieldProps } from '@mui/material';

export type RenderPasswordFieldProps = {} & TextFieldProps;

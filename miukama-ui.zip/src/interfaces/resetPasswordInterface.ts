'use client';

export interface resetPasswordInterface {
  password: string;
  confirmPassword: string;
}

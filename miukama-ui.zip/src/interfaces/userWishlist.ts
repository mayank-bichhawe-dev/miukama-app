export interface userWishlistItem {
  productId: number;
  ownerName: string;
  totalItem: number;
}

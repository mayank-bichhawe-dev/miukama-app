export interface Categories {
  value: string | number;
  label: string;
}

export interface ContactProps {
  contact: string;
  description: string;
  name: string;
}
